# Bucket List 🪣
# Codédex

things_to_do = [
   '🚀 Build a meaningful product for everyone.',
   '⛰ Try out hiking and mountain biking.',
   '🌏 Visit at least 10 countries in my lifetime.',
   '🎸 Produce an original song.',
   '📝 Write a short story.',
   '🏃 Finish a 10k marathon.'
]

for thing in things_to_do:
  print(thing)
