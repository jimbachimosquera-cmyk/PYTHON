# Inventory 📦
# Codédex

lego_parts = [8980, 7323, 5343, 82700, 92232, 1203, 7319, 8903, 2328, 1279, 679, 589]

print(min(lego_parts))
print(max(lego_parts))
