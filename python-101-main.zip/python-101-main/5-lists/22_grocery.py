# Grocery List 🛒
# Codédex

grocery = ['🥚 Eggs', 
           '🥑 Avocados', 
           '🍪 Cookies', 
           '🌶 Hot Pepper Jam', 
           '🫐 Blueberries', 
           '🥦 Broccoli']

print(grocery)
