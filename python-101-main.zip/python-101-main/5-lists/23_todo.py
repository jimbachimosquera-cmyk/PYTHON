# To-Do List ✅
# Codédex

todo = ['🏦 Get quarters.', 
        '🧺 Do laundry.',
        '🌳 Take a walk.',
        '💈 Get a haircut.',
        '🍵 Make some tea.',
        '💻 Complete Lists chapter.',
        '💖 Call mom.',
        '📺 Watch My Hero Academia.']

print(todo[0])
print(todo[1])
print(todo[2 : 5])
print(todo[9]) # IndexError
