# Pythagorean Theorem 📐
# Codédex

a = int(input("Enter a: "))
b = int(input("Enter b: "))

c = (a**2 + b**2) ** 0.5

print(c)
