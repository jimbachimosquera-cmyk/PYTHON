# Mars Orbiter 🚀
# Codédex

def distance_to_miles(distance):
    miles = distance / 1.609
    print(miles)

distance_to_miles(10000)
