# D.R.Y. 🧩
# Codédex

import random

list_of_foods = ['celery', 'broccoli', 'cabbage']

# This was the first function introduced in the course
print('Hello, World!')

# This function calculates the maximum of two numbers a and b
print(max(3, 5))

# This function calculates the minimum of two numbers a and b
print(min(-1, 7))

# This function calculates the length of a list
print(len(list_of_foods))

# This function calculates a to the power b
print(pow(2, 6))
