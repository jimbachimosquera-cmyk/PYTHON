# Snail Mail 💌
# Codédex

print('+---------------------------------------------------------------------+')
print('|                                                                     |')
print('|                                                                     |')
print('|        Wrote myself a letter                                        |')
print('|        just a single question                                       |')
print('|                                                                     |')
print('|        "When you finally get this, where will you be?" ✨           |')
print('|                                                                     |')
print('|        Will you be a shipwreck or a star                            |')
print('|        Falling for a boy who doesn\'t play guitar?                  |')
print('|        Now rewind the tape back to the start                        |')
print('|                                                                     |')
print('|                                          - Caroline Polachek        |')
print('|                                                                     |')
print('|                                                                     |')
print('+---------------------------------------------------------------------+')
