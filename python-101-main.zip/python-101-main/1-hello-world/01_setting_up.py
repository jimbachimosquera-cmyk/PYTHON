# Write code below 💖

print('Hi')
