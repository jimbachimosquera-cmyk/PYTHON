# Snail Mail 💌
# Codédex

print('+---------------------------------------------------------------------+')
print('|                                                                     |')
print('|                                                        June 2022    |')
print('|                                                     Brooklyn, NY    |')
print('|         Dear Self,                                                  |')
print('|                                                                     |')
print('|         Build the platform you always dreamed of —                  |')
print('|         the one you wish existed when you started.                  |')
print('|         Give more than you take.                                    |')
print('|         Care > capital.                                             |')
print('|         Five-second funerals for all the Ls.                        |')
print('|         And always get back up.                                     |')
print('|                                                                     |')
print('|                                                 Sonny 🤠            |')
print('|                                                                     |')
print('+---------------------------------------------------------------------+')
