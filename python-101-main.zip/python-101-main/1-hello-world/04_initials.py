# Fun fact: My high school band Attica was signed to an indie record label. 🤘

print(' SSS   L    ')
print('S   S  L    ')
print('S      L    ')
print(' SSS   L    ')
print('    S  L    ')
print('S   S  L    ')
print(' SSS   LLLLL')
