# Detention 🧑‍🏫
# Codédex

for x in range(100):
  print('I will not throw airplanes in class')
